package com.naveen.assignmentportal.exception;

//public class CustomException extends RuntimeException {
//    public CustomException(String message) {
//        super(message);
//    }
//}
