package com.naveen.assignmentportal.entity;

public enum Status {
    PENDING, ACCEPTED, REJECTED
}
