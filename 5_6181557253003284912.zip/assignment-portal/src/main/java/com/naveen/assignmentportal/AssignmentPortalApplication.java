package com.naveen.assignmentportal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AssignmentPortalApplication {

    public static void main(String[] args) {
        SpringApplication.run(AssignmentPortalApplication.class, args);
    }

}
