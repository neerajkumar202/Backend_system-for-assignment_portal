package com.naveen.assignmentportal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssignmentPortalApplicationTests {

    @Test
    void contextLoads() {
    }

}
